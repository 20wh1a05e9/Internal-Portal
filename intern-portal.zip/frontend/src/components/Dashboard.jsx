import React, { useEffect, useState } from 'react';

export default function Dashboard() {
  const [intern, setIntern] = useState(null);

  useEffect(() => {
    fetch('/api/intern')
      .then(res => res.json())
      .then(data => setIntern(data));
  }, []);

  if (!intern) return <p>Loading intern data...</p>;

  return (
    <div className="dashboard">
      <h2>Intern Dashboard</h2>
      <p><strong>Name:</strong> {intern.name}</p>
      <p><strong>Referral Code:</strong> {intern.referralCode}</p>
      <p><strong>Donations Raised:</strong> ${intern.donationsRaised}</p>
      <p><strong>Rewards:</strong> {intern.rewards.join(', ')}</p>
    </div>
  );
}