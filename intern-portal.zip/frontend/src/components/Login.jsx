import React from 'react';

export default function Login() {
  return (
    <div className="login">
      <h2>Login (Mock)</h2>
      <input placeholder="Username" />
      <input placeholder="Password" type="password" />
      <button>Login</button>
    </div>
  );
}