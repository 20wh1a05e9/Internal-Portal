import { useState } from 'react';
import Leaderboard from './components/Leaderboard';
import Dashboard from './components/Dashboard';
import Login from './components/Login';
import './index.css';

export default function App() {
  const [activeTab, setActiveTab] = useState('dashboard');

  return (
    <div className="app">
      <nav>
        <button onClick={() => setActiveTab('dashboard')}>Dashboard</button>
        <button onClick={() => setActiveTab('leaderboard')}>Leaderboard</button>
      </nav>
      {activeTab === 'dashboard' ? <Dashboard /> : <Leaderboard />}
      <Login />
    </div>
  );
}